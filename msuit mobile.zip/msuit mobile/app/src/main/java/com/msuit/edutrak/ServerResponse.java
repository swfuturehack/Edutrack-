package com.msuit.edutrak;

class ServerResponse {

    // variable name should be same as in the json response from php
    int status ;
    String message;

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
