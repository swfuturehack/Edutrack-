package com.msuit.edutrak;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class RetroClient {
    //private static final String BASE_URL = "http://api.mafoundation.com.ng/";
    private static final String BASE_URL = "https://islamicwebsearch.com/ees/api/";
    private static RetroClient mInstance;

    private static Retrofit mAPIClient;
  //  private static String mToken;

    private RetroClient() {
        Gson gson = new GsonBuilder()
                .serializeNulls()
                .setLenient()
                .create();

//        OkHttpClient okHttpClient = new OkHttpClient.Builder().addInterceptor(new Interceptor() {
//            @Override
//            public Response intercept(Chain chain) throws IOException {
//                Request request = chain.request().newBuilder().addHeader("Authorization", "Bearer " )
//                        .build();
//                return chain.proceed(request);
//            }
//        })
//                .readTimeout(120, TimeUnit.SECONDS)
//                .connectTimeout(120, TimeUnit.SECONDS)
//                .build();

        OkHttpClient okHttpClient = new OkHttpClient();
        mAPIClient = new Retrofit.Builder()
                .client(okHttpClient)
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
    }

    public static synchronized RetroClient getInstance() {

        if (mInstance == null) {
         //   mToken = token;
            mInstance = new RetroClient();
        }
        return mInstance;
    }

    public api getAPI() {
        return mAPIClient.create(api.class);
    }

}
