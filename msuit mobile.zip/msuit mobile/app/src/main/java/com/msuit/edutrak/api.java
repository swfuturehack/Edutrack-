package com.msuit.edutrak;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface api {

    @Multipart
    @POST("audio_upload")
    Call<ServerResponse> upload(
            @Part("name") RequestBody name,
            @Part MultipartBody.Part uploaded_file
    );

}
